//
// Created by roland on 11/9/19.
//

#ifndef CS260_ASSIGNMENT2_ROLANDSHUM_UTILITY_H
#define CS260_ASSIGNMENT2_ROLANDSHUM_UTILITY_H


class Utility
{
public:
    static std::string Sprintf( const char* inFormat, ... );
};


#endif //CS260_ASSIGNMENT2_ROLANDSHUM_UTILITY_H
